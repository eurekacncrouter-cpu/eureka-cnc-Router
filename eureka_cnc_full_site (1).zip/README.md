# Eureka CNC Router — Sitio Web (Versión Completa)

Este paquete incluye la versión completa del sitio web estático.

## Contenido
- index.html (versión completa)
- versión minificada
- carpeta /assets si deseas agregar imágenes

## Deploy
Compatible con:
- Netlify
- Vercel
- GitHub Pages
